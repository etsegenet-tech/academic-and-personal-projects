import { useState } from "react";
import "./App.css";

function App() {
  const [title, setTitle] = useState("");
  const [creator, setCreator] = useState("");
  const [category, setCategory] = useState("Photography");
  const [description, setDescription] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [works, setWorks] = useState([]);
  function handleSubmit(event) {
    event.preventDefault();

    const newWork = {
      id: Date.now(),
      title: title,
      creator: creator,
      category: category,
      description: description,
      imageUrl: imageUrl,
    };

    setWorks((previousWorks) => [...previousWorks, newWork]);

    setTitle("");
    setCreator("");
    setCategory("Photography");
    setDescription("");
    setImageUrl("");
  }
  return (
    <div className="app">
      <header className="hero">
        <h1>CreatorsHub</h1>
        <p>
          A place for photographers and designers to share their creativity.
        </p>
      </header>

      <main>
        <h2>Add Your Creative Work</h2>

        <form className="work-form" onSubmit={handleSubmit}>
          <div className="form-grid">
            <div className="form-field">
              <label htmlFor="title">Work Title</label>
              <input
                id="title"
                type="text"
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                placeholder="Enter the title"
                required
              />
            </div>

            <div className="form-field">
              <label htmlFor="creator">Creator Name</label>
              <input
                id="creator"
                type="text"
                value={creator}
                onChange={(event) => setCreator(event.target.value)}
                placeholder="Enter your name"
                required
              />
            </div>

            <div className="form-field">
              <label htmlFor="category">Category</label>
              <select
                id="category"
                value={category}
                onChange={(event) => setCategory(event.target.value)}
              >
                <option>Photography</option>
                <option>Fashion</option>
                <option>Landscape</option>
                <option>Culture</option>
                <option>Other</option>
              </select>
            </div>

            <div className="form-field">
              <label htmlFor="photo">Upload Your Photo</label>
              <input
                id="photo"
                type="file"
                accept="image/*"
                onChange={(event) => {
                  const file = event.target.files[0];

                  if (file) {
                    setImageUrl(URL.createObjectURL(file));
                  }
                }}
              />
            </div>

            <div className="form-field full-width">
              <label htmlFor="description">Description</label>
              <textarea
                id="description"
                value={description}
                onChange={(event) => setDescription(event.target.value)}
                placeholder="Describe your creative work"
                required
              />
            </div>
          </div>

          <button type="submit">Submit Work</button>
        </form>
        <section className="gallery">
          <h2>Our Creative Gallery</h2>

          {works.length === 0 ? (
            <p>No creative works have been submitted yet.</p>
          ) : (
            <div className="work-list">
              {works.map((work) => (
                <div className="work-card" key={work.id}>
                  {work.imageUrl ? (
                    <img
                      src={work.imageUrl}
                      alt={work.title}
                      className="work-image"
                    />
                  ) : (
                    <p>No photo uploaded for this work.</p>
                  )}

                  <div className="work-details">
                    <h3>{work.title}</h3>
                    <p>
                      <strong>Creator:</strong> {work.creator}
                    </p>
                    <p>
                      <strong>Category:</strong> {work.category}
                    </p>
                    <p>{work.description}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
export default App;
